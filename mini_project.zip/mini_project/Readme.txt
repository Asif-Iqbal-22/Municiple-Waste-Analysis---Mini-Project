Municipal Waste Collection Efficiency and Zone Analysis

A modular Python data science application and interactive web dashboard built for the BTCS2101 Programming with Python mini project at Assam down town University.

🚀 Project Overview

Municipal waste management is a critical urban challenge. This application processes, cleans, and analyzes municipal waste datasets to evaluate collection efficiency across various districts and waste categories. Built using a clean modular architecture, it automates data sanitization, computes performance metrics, classifies ward statuses, generates statistical charts, and presents actionable insights through an interactive Streamlit web interface.

 Team Members

Abhinav Singh (Roll No. 023) — Data Loading, Cleaning Modules & Architecture

Asif Iqbal (Roll No. 055) — Analysis Logic, Streamlit Dashboard UI & Testing

 Project Structure

Municipal-Waste-Analyser/
├── app.py                  # Main Streamlit web application & interface logic
├── data_loader.py          # CSV ingestion, validation, and data cleaning module
├── analyzer.py             # Metric calculations, status classification, & plotting
├── requirements.txt        # External library dependencies
├── README.md               # Project documentation
├── data/
│   └── waste_data.csv      # Input municipal dataset (850 rows, 13 attributes)
└── plots/
    └── efficiency_distribution.png  # Generated statistical histogram


Tech Stack & Libraries

Python 3.13 — Core programming language

pandas (v2.2.3) — Data ingestion, cleaning, manipulation, and DataFrame processing

NumPy (v2.5.4) — Numerical computations and array operations

Matplotlib (v3.10.0) & Seaborn (v0.13.2) — Statistical visualizations and chart generation

Streamlit (v1.42.0) —
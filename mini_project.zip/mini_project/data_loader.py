import pandas as pd
import os

class WasteDataLoader:
    """Handles loading, cleaning, and exception handling for the municipal waste dataset."""
    
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = None

    def load_and_clean_data(self) -> pd.DataFrame:
        """Loads CSV, handles missing values and file errors, and removes duplicates."""
        try:
            if not os.path.exists(self.file_path):
                raise FileNotFoundError(f"Dataset missing at: {self.file_path}")
            
            # File handling: reading CSV
            self.df = pd.read_csv(self.file_path)
            
            # Clean data: drop duplicate rows
            initial_count = len(self.df)
            self.df.drop_duplicates(inplace=True)
            
            # Handle missing values in numeric columns
            self.df.fillna(0, inplace=True)
            
            print(f"Loaded {initial_count} rows. Cleaned dataset shape: {self.df.shape}")
            return self.df
            
        except FileNotFoundError as e:
            print(f"File Error: {e}")
            raise
        except pd.errors.EmptyDataError:
            print("Error: The CSV file is empty.")
            raise
        except Exception as e:
            print(f"Unexpected error during data loading: {e}")
            raise
import streamlit as st
import pandas as pd
from data_loader import WasteDataLoader
from analyzer import WasteAnalyzer
import os

st.title("Municipal Waste & Collection Efficiency Analyser")
st.write("**BTCS2101 Python Programming Mini Project** · Assam down town University")

data_path = "data/waste_data.csv"

if os.path.exists(data_path):
    # Load and clean data using session state so added/deleted records persist during your session
    if 'df_live' not in st.session_state:
        loader = WasteDataLoader(data_path)
        df_raw = loader.load_and_clean_data()
        analyzer = WasteAnalyzer(df_raw)
        st.session_state['df_live'] = analyzer.processed_df

    df_processed = st.session_state['df_live']

    # Sidebar Controls & Interactive Features
    st.sidebar.header("Interactive Controls")
    status_filter = st.sidebar.selectbox("Filter by Status", ["All", "Optimal", "Moderate", "Critical"])
    search_query = st.sidebar.text_input("Search District or Waste Type")

    # Feature: Live Record Simulator with Mandatory & Comprehensive Optional Fields
    st.sidebar.subheader("➕ Add New Record")
    with st.sidebar.form("add_record_form"):
        st.sidebar.write("**Mandatory Fields**")
        new_city = st.text_input("City/District Name *", "Guwahati")
        new_waste_type = st.selectbox("Waste Type *", ["Plastic", "Organic", "E-Waste", "Construction", "Hazardous"])
        new_gen = st.number_input("Waste Generated (Tons/Day) *", min_value=0.0, value=1200.0)
        new_rec = st.number_input("Recycling Rate (%) *", min_value=0.0, max_value=100.0, value=75.0)
        
        st.sidebar.write("---")
        st.sidebar.write("**Optional Fields**")
        opt_density = st.number_input("Population Density (People/km²)", min_value=0.0, value=850.0)
        opt_score = st.number_input("Municipal Efficiency Score (1-10)", min_value=1.0, max_value=10.0, value=7.0)
        opt_disposal = st.text_input("Disposal Method", "Composting")
        opt_cost = st.number_input("Cost of Waste Management (₹/Ton)", min_value=0.0, value=3000.0)
        opt_campaigns = st.number_input("Awareness Campaigns Count", min_value=0, value=10)
        opt_landfill = st.text_input("Landfill Name", "Central Landfill")
        opt_latlong = st.text_input("Landfill Location (Lat, Long)", "26.1445, 91.7362")
        opt_capacity = st.number_input("Landfill Capacity (Tons)", min_value=0.0, value=50000.0)
        opt_year = st.number_input("Year", min_value=2000, max_value=2030, value=2026)
        
        submitted = st.form_submit_button("Add Record")
        
        if submitted:
            if not new_city.strip():
                st.sidebar.error("City/District name cannot be blank.")
            else:
                eff = new_rec
                status = 'Optimal' if eff >= 70.0 else ('Moderate' if eff >= 50.0 else 'Critical')
                
                new_row = {
                    'City/District': new_city,
                    'Waste Type': new_waste_type,
                    'Waste Generated (Tons/Day)': new_gen,
                    'Recycling Rate (%)': new_rec,
                    'Population Density (People/km²)': opt_density,
                    'Municipal Efficiency Score (1-10)': opt_score,
                    'Disposal Method': opt_disposal,
                    'Cost of Waste Management (₹/Ton)': opt_cost,
                    'Awareness Campaigns Count': opt_campaigns,
                    'Landfill Name': opt_landfill,
                    'Landfill Location (Lat, Long)': opt_latlong,
                    'Landfill Capacity (Tons)': opt_capacity,
                    'Year': opt_year,
                    'Collection_Efficiency_%': eff,
                    'Status': status
                }

                st.session_state['df_live'] = pd.concat([st.session_state['df_live'], pd.DataFrame([new_row])], ignore_index=True)
                st.sidebar.success(f"Added record for {new_city} successfully!")
                st.rerun()

    # Feature: Precise Delete Record Tool
    st.sidebar.subheader("🗑️ Delete Record")
    if not st.session_state['df_live'].empty:
        df_current = st.session_state['df_live']
        row_to_delete = st.sidebar.selectbox(
            "Select Row to Delete",
            options=df_current.index,
            format_func=lambda idx: f"Row {idx}: {df_current.loc[idx, 'City/District'] if 'City/District' in df_current.columns else idx}"
        )
        if st.sidebar.button("Delete Selected Row"):
            st.session_state['df_live'] = df_current.drop(index=row_to_delete).reset_index(drop=True)
            st.sidebar.success(f"Successfully deleted row {row_to_delete}!")
            st.rerun()

    # Apply filters and search query
    display_df = st.session_state['df_live'].copy()
    if status_filter != "All":
        display_df = display_df[display_df['Status'] == status_filter]
        
    if search_query:
        string_cols = display_df.select_dtypes(include=['object']).columns
        mask = display_df[string_cols].apply(lambda x: x.str.contains(search_query, case=False, na=False)).any(axis=1)
        display_df = display_df[mask]

    # Key Metrics Dashboard
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Records Analysed", len(st.session_state['df_live']))
    col2.metric("Average Efficiency", f"{st.session_state['df_live']['Collection_Efficiency_%'].mean():.2f}%")
    col3.metric("Critical Records", len(st.session_state['df_live'][st.session_state['df_live']['Status'] == 'Critical']))

    st.subheader("Processed Data Table")
    st.dataframe(display_df, use_container_width=True)

    # Dual Visual Charts Section
    st.subheader("Visual Analytics & Charts")
    chart_col1, chart_col2 = st.columns(2)
    
    with chart_col1:
        st.write("**Average Efficiency by City/District**")
        if 'City/District' in st.session_state['df_live'].columns:
            chart_data1 = st.session_state['df_live'].groupby('City/District')['Collection_Efficiency_%'].mean()
            st.bar_chart(chart_data1)
        
    with chart_col2:
        st.write("**Total Waste Generated by Waste Type**")
        if 'Waste Type' in st.session_state['df_live'].columns and 'Waste Generated (Tons/Day)' in st.session_state['df_live'].columns:
            chart_data2 = st.session_state['df_live'].groupby('Waste Type')['Waste Generated (Tons/Day)'].sum()
            st.bar_chart(chart_data2)

    # CSV Export button
    if st.button("Export Processed Report to CSV"):
        output_file = "data/processed_waste_report.csv"
        st.session_state['df_live'].to_csv(output_file, index=False)
        st.success(f"Report successfully exported to {output_file}!")

else:
    st.error(f"Dataset not found at '{data_path}'. Please place your CSV file in the 'data/' folder.")
    
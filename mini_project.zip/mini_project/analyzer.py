import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

class WasteAnalyzer:
    """Computes collection efficiency metrics and generates analytical visualisations."""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.processed_df = self._process_metrics()

    def _process_metrics(self) -> pd.DataFrame:
        """Assigns efficiency metrics and status categories based on the dataset."""
        df = self.df.copy()
        
        # Use Recycling Rate (%) directly as the efficiency percentage
        if 'Recycling Rate (%)' in df.columns:
            df['Collection_Efficiency_%'] = df['Recycling Rate (%)'].astype(float).round(2)
        else:
            # Fallback if column name differs slightly
            df['Collection_Efficiency_%'] = df.iloc[:, 3].astype(float).round(2)
        
        # Categorise wards using threshold logic
        def classify_status(eff):
            if eff >= 70.0:
                return 'Optimal'
            elif eff >= 50.0:
                return 'Moderate'
            else:
                return 'Critical'

        df['Status'] = df['Collection_Efficiency_%'].apply(classify_status)
        return df

    def generate_charts(self, output_dir: str = "plots"):
        """Generates and saves Matplotlib/Seaborn charts for the report and presentation."""
        os.makedirs(output_dir, exist_ok=True)
        sns.set_theme(style="whitegrid")

        # Chart 1: Efficiency Distribution Histogram
        plt.figure(figsize=(8, 5))
        sns.histplot(self.processed_df['Collection_Efficiency_%'], bins=10, kde=True, color='teal')
        plt.title("Distribution of Ward Collection Efficiency")
        plt.xlabel("Collection Efficiency (%)")
        plt.ylabel("Number of Wards")
        plt.savefig(os.path.join(output_dir, "efficiency_distribution.png"))
        plt.close()

        print(f"Charts saved successfully in '{output_dir}/'")